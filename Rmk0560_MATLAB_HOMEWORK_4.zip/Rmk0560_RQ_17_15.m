%Ruth Kebede              %ENGR1250_006      April-19-2019

%problem statement-testing the unknown material when heat is applied and
%causing change in temprature.then test the relationship using polyfit
%{
variables
Q=heat energy[J]
T=temprature[K]
%}

clc
clear
close all

%given
Q= [12,17,25,40,50,58];             %heat[J]
T=[1.50,2.00,3.25,5.00,6.25,7.00];  %temprature[K]

%polyfit
C=polyfit(Q,T,1);  %linear relation 

m=C(1); % Slope of the linear graph     
b=C(2);  % value of the constant 

%y=mx+b
Q2=[12:5:60];       %heat[J]
T2=m*Q2+b;          %temprature[K]

%plot
figure('color','w')
plot(Q,T,'dr','MarkerFaceColor','b','MarkerSize',14)
hold on
plot(Q2,T2,'-r','linewidth',3)

TE=sprintf('T=%0.3f*Q+%0.3f',m,b);
text(40,3.25,TE,'backgroundcolor','w','edgecolor','m','color','r','fontsize',12)

%title
title('linear relation between Temprature and heat ')

%axis
axis([10 60 1 8])

%label
xlabel('Heat Applied(Q)[J]','FontSize',12)
ylabel('Temperature (\DeltaT) [K]','FontSize',12)

%grid
grid on