%Ruth Kebede       ENGR1250   006       03/23/2019
%Problem: finding heat needed to increase the temprature
clear allclose all;
clc;
%variables
Name=input('name of person:','s');
days=menu{'monday','wednesday','friday'};
weekdays=menu('which day of the week?',days);
mass=input('mass of the substance[grams]:');
c=input('specific heat of substance[J/kg*k]:');
Tini=input(' initial temprature[F]:');
Tfin=input('final temprature[F]:');
%convert degree F to  degree K
Tin=((Tini-32)/1.8)+273;
Tfi=((Tfin-32)/1.8)+273;
%convert grams to kg
mass=mass/1000;
%calculate change in temperature
T=Tfi-Tin;%[K]
%Find heat
Q-mass*c*T%[J]
fprintf('n\\n0n %s, the user %s entered a %0.2f mass in grams with a',days{choice},Name,mass);
fprintf('nspecific heat of %0.2fJ/kg*K that should be raised from %0.2f',c,Tini);
fprintf('\ndegrees Farenhiet to 0.2f  degree Farenhiet,',Tfin);
fprintf('\nthis should require %0.1f J of heat to the substance',Q);

V=input('Enter the value of volume[m^3]:'); 
%Enter the values of specific gravity and density of water
sg=4.7


