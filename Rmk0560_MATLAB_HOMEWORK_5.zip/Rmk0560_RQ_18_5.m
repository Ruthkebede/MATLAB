%Ruth Kebede             ENGR_1250_006             April-27-2019

%problem statement-To write a program asking the use to input the mass of a
%cube gold [kg] and dispay the length of a single side[inches]


%{
variables
p_water=density of water[kg/m^3]
p-density of cube[kg/m^3]
sg-specific gravity[-]
mass- mass of cube[kg]
volume-volume[m^3]
length-length[inches]
%}


%{
known constants
p_water=1000   ;%[kg/m^3]
%}

clc
clear
close all


%specific gravity of gold
sg=19.3;      %[-]

%density of water
p_water=1000;   % [kg/m^3]

%density of cube
p=sg*p_water;   %[kg/m^3]

%input the mass
mass=input('Enter mass of cube in [kilograms]:');

%find volume
volume=mass/p; %[m^3]

%In meters
length=nthroot(volume,3); 

%convert to inches
length=length*100/2.54; 

%condition for mass
if(mass<=0)
error('mass must be greater than zero kilograms')
end

%output
fprintf('The length of one side of cube is %0.2f inches\n',length);
