%ruth kebede             ENGR1250_006            April-19-2019

%problem statment-Experiment on the size that a working gear can be changed
%with time
%{
variable
T= temprature[K]
MGS= minimum gear size[mm]
%}
clc
clear
close all

%given
T=[0 5 7 16 25 31 37];                        %years[Yr]
MGS=[0.8 0.4 0.2 0.09 0.007 2e-04 8e-06];    %minimum gear size[mm]

%y= b^(x*m)
%polyfit
C=polyfit(T,log(MGS),1);

m=C(1);     %coefficient of independent variable
b=exp(C(2));   %coefficient of e  

T2=[0:37];         %years[Yr]
MGS2=b*exp(m*T2);   %minimum gear size[mm]


%plot
figure('Color','w')
plot(T,MGS,'sk','MarkerFaceColor','r','MarkerSize',9)
hold on
plot(T2,MGS2,'linewidth',3)

%plot trendline equation
TE=sprintf('MGS=%0.2f e^{%0.3fT}',b,m);
text(16,0.5,TE,'backgroundcolor','w','edgecolor','m','color','m','fontsize',18);

%title
title('Rate of change of gear with time ')

%axis
axis([0 40 0 1])

%label
xlabel('Year from 1967(t) [yr]','FontSize',12)
ylabel('Minimum gear size(MGS)[mm]')

%grid
grid on