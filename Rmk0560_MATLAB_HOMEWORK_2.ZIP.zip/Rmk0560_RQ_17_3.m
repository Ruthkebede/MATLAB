%Ruth Kebede           ENGR1250   006      3/23/2019
%problem: to find the weight of object in pound force on callisto
clear;clc;
%variables
%'v-volume [m^3]
%sg- specific gravity
%p- density of water[kg/[m^3]
%po- density of object[kg/m^3]
%m- mass of object[kg]
%g-acceleration[m/s^2]
%w-weight of object[lbf]
%enter value for volume
v=input('enter the value for volume[m^3]:');
%enter value for specific gravity and density for water
sg=4.7
p=1000;
%find density for the rod
m=Po*v;
%input value for g and cslculate weight
g=1.25;%[m/s^2]
w=m*g%[N]
%converet w to lbf
w=w*0.225;%[lbf]
fprintf('the weight of rod in lbf is %0.0f pound force\n'w);
