%Ruth Kebede             ENGR1250_006        3/30/2019
%problem statement- creat a proper plot of the height and radius
clc
clear
Radius=[0.01 0.05 0.10  0.20 0.40 0.50];%radius in [cm]
Height=[14.0 3.0 1.5 0.8 0.4 0.2];%height in[cm]
%plot graph
figure('color','w')
plot(Radius,Height,'ob','MarkerSize',12,'MarkerFaceColor','r')
grid 
axis([0 0.8 0 16])
%label
xlabel('Radius(r)[cm]')
ylabel('Height(H)[cm]')
%giving title
title('Capillary Action')
set(gca,'XTick',0:0.02:50)
set(gca,'YTick',0:0.5:60)
