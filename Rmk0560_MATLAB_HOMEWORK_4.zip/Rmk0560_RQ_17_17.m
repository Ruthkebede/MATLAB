%Ruth Kebede                    ENGR1250_006          April-19-2019-

%problem statment- experimenting a mixing device that depends on size
%{
variabels
D- diameter[mm]
P=power[hp]
%}

clc
clear
close all

%given
D=[0.5 0.75 1 1.5 2 2.25 2.5 2.75];             %Diameter[ft]
P=[0.004 0.04 0.13 0.65 3 8 18 22];             %power[hp]

%polyfit
C= polyfit(log10(D),log10(P),1);

m=C(1);      %power of independent variable
b=10^C(2);    %coefficient of independent variable

%y = b*x^m
D2=[0.5:0.1:3];        %diameter in [ft]
P2=b.*D2.^m;           %power[hp]

%plot
figure('Color','w')
plot(D,P,'sb','MarkerFaceColor','b','MarkerSize',14)
hold on
plot(D2,P2,'-K','linewidth',3)

%plot trendline equation
TE=sprintf('P = %0.2f D^{%1.0f}',b,m);
text(1,10,TE,'backgroundcolor','w','edgecolor','b','color','b','fontsize',18)

%title
title('Power change relative to diameter')

%axis
axis([0 3 0 25])

%label
xlabel('Diameter(D)[ft]')
ylabel('Power(P)[hp]')

%grid
grid on