%Ruth Kebede     ENGR1250   006    3/23/2019
%problem: finding the temprature in degree fahrenheit
clear;
clc;
%input variables
Deg F= input('what is the temprature in degree fahrenheit that you want to convert to?');
%convert 
choose_unit=menu('what unit do you want to convert your temprature to?','Degc','k','DegR');
%convert the temprature [deg F]to [deg c],[k] and [deg R]
Deg_c=(5*(deg_f-32))/9;
K= Deg_c+273
Deg_R=DEG_F-460;
units_conversion=[Deg_c k Deg_R];
units={'deg c' 'k' 'deg R'};
fprintf('the equivalent tempertatureto 0.0f %s \n', Deg_f, units_conversion{choose_unit},{choose_units})
