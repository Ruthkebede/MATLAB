%Ruth Kebede           ENGR1250_006              3/29/2019
%problem statement- creating a proper plot of distance and speed of
%a vehicle
clc
clear

speed=[20 30 40 50 60 70];%vehicles speed in[miles per hour]
dr=[6 9 12 15 18 21];     %reaction distance in [m]
db=[6 14 24 38 55 75];    %braking distance in[m]
dr=dr/1000;     %convert [m] to [km] 
dr=dr*0.621;    %convert [km] to [mi]
db=db/1000;     %convert [m] to [km]
db=db*0.621;    %convert [km] to [mi]
%plot
figure('color','w')
plot(speed,dr,'s','MarkerSize',16,'MarkerFaceColor','k')
hold on
plot(speed,db,'o','MarkerSize',10,'MarkerFaceColor','m')
grid
axis([0 80 0 0.06])
%label
xlabel('Vehicle Speed (v)[mph]')
ylabel('Distance(d)[mi]')
%title
title('reaction Time')
legend('reaction distance','breaking distance','location','best')
set(gca,'Xtick',0:10:80);
set(gca,'Ytick',0:0.01:0.06);

