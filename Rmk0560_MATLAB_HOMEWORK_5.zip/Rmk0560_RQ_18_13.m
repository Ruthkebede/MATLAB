%Ruth Kebede         ENGR_1250_006              April-27-2019

%Problem Statment-create a program to determine if a user-specified
%wavelength [nanometer, nm] is one of the six spectral colors listed.

%variables
%wave- wavelength[nm]

clc
clear
close all

%input
Wave=input('Enter a wavelength[nanometer,nm]:');

% wavelength interval and outputs
if(Wave>700 || Wave<400)
fprintf('It is not within the visible spectrum')
elseif (Wave<=700 && Wave>=635)
    fprintf('Red\n')
elseif(Wave<635 && Wave>=590)
    fprintf('Orange\n')
elseif(Wave<590 && Wave>=560)
    fprintf('Yellow\n')
elseif(Wave<560 &&Wave>=490)
    fprintf('Green\n')
elseif(Wave<490 && Wave>=450)
    fprintf('Blue\n')
else
    fprintf('Violet\n')
end