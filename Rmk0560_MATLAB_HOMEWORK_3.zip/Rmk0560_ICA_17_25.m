%Ruth Kebede           ENGR1250_006           3/30/2019
%problem statment-creat a plot of theoretical voltage decay of a resistor-capacitor circuit

clear
clc
c=500;%capacitance in [microfarads]
R=0.5;%resistance in [ohms]
Vo=10;%initial voltage in [V]
T= [0:50:600];%time [microseconds]
V=Vo*exp(-T/(R*c));
%plot
figure('color','w')
plot(T,V,'or','MarkerSize',16','MarkerFaceColor','b')
grid
axis([0 600 0 12])
%label
xlabel('time(t)[ms]')
ylabel('voltage(V)[V]')
title('voltage decay')
set(gca,'Xtick',0:50:600)
set(gca,'Ytick',0:0.6:12)



