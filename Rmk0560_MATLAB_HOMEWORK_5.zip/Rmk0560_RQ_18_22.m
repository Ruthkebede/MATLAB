%Ruth Kebede         ENGR1250_006      April-27-2019

%problem statment-create a program that allows the student to select the grade earned in a course from a menu

clc
clear
close all

%creat a menu
grade=menu('Select the grade earned:','A','B','C','D','F');

%condition for grade
if grade==1
   fprintf('If you earn the letter grade A, your numeric grade is in the range:\n90<=grade\n')
elseif grade==2
   fprintf('If you earn the letter grade B, your numeric grade is in the range:\n80<=grade<90\n')
elseif grade==3
    fprintf('If you earn the letter grade C, your numeric grade is in the range:\n70<=grade<80\n')
elseif grade==4
    fprintf('If you earn the letter grade D, your numeric grade is in the range:\n60<=grade<70\n')
elseif grade==5
    fprintf('If you earn the letter grade F, your numeric grade is in the range:\ngrade<60\n')
else
    error('no selection')
end